const STORAGE_KEY = "taskflow_tasks";

export function guardarTareas(tareas) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(tareas));
}

export function cargarTareas() {
  return localStorage.getItem(STORAGE_KEY);
}
