import { TaskFlowApp } from "./TaskFlowApp.js";

const app = new TaskFlowApp();
app.init();
