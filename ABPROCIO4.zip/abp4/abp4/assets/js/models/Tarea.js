export class Tarea {
  constructor({
    id = crypto.randomUUID(),
    descripcion,
    estado = "pendiente",
    fechaCreacion = new Date().toISOString(),
    fechaLimite = "",
  }) {
    this.id = id;
    this.descripcion = descripcion.trim();
    this.estado = estado;
    this.fechaCreacion = fechaCreacion;
    this.fechaLimite = fechaLimite;
  }

  cambiarEstado() {
    this.estado = this.estado === "pendiente" ? "completada" : "pendiente";
  }

  actualizarDescripcion(nuevaDescripcion) {
    this.descripcion = nuevaDescripcion.trim();
  }

  actualizarFechaLimite(nuevaFecha) {
    this.fechaLimite = nuevaFecha;
  }
}
