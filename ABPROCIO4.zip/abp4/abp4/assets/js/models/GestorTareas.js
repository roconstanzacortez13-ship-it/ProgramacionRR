export class GestorTareas {
  constructor() {
    this.tareas = [];
  }

  agregarTarea(tarea) {
    this.tareas = [...this.tareas, tarea];
  }

  eliminarTarea(id) {
    this.tareas = this.tareas.filter((tarea) => tarea.id !== id);
  }

  obtenerTarea(id) {
    return this.tareas.find((tarea) => tarea.id === id);
  }

  actualizarTarea(id, datos) {
    const tarea = this.obtenerTarea(id);

    if (!tarea) {
      return;
    }

    if (datos.descripcion) {
      tarea.actualizarDescripcion(datos.descripcion);
    }

    tarea.actualizarFechaLimite(datos.fechaLimite ?? tarea.fechaLimite);
  }

  alternarEstado(id) {
    const tarea = this.obtenerTarea(id);

    if (tarea) {
      tarea.cambiarEstado();
    }
  }

  reemplazarTareas(tareas) {
    this.tareas = [...tareas];
  }

  limpiar() {
    this.tareas = [];
  }
}
