import { Tarea } from "./models/Tarea.js";
import { GestorTareas } from "./models/GestorTareas.js";
import { guardarTareas, cargarTareas } from "./storage/storage.js";

export class TaskFlowApp {
  constructor() {
    this.gestor = new GestorTareas();
    this.editingId = null;
    this.countdownInterval = null;

    this.elements = {
      form: document.querySelector("#task-form"),
      taskId: document.querySelector("#task-id"),
      description: document.querySelector("#task-desc"),
      dueDate: document.querySelector("#task-due-date"),
      submitBtn: document.querySelector("#submit-btn"),
      cancelEdit: document.querySelector("#cancel-edit"),
      clearAll: document.querySelector("#clear-all"),
      search: document.querySelector("#search-input"),
      taskList: document.querySelector("#task-list"),
      template: document.querySelector("#task-template"),
      notification: document.querySelector("#notification"),
      liveHint: document.querySelector("#live-hint"),
      statTotal: document.querySelector("#stat-total"),
      statPending: document.querySelector("#stat-pending"),
      statCompleted: document.querySelector("#stat-completed"),
      syncStatus: document.querySelector("#sync-status"),
      clock: document.querySelector("#clock"),
    };
  }

  init() {
    this.cargarDesdeLocalStorage();
    this.bindEvents();
    this.render();
    this.iniciarReloj();
    this.iniciarCountdown();
  }

  bindEvents() {
    this.elements.form.addEventListener("submit", (event) => this.handleSubmit(event));
    this.elements.cancelEdit.addEventListener("click", () => this.resetForm());
    this.elements.clearAll.addEventListener("click", () => this.handleClearAll());
    this.elements.search.addEventListener("keyup", () => this.render());

    this.elements.description.addEventListener("keyup", (event) => {
      const caracteres = event.target.value.trim().length;
      this.elements.liveHint.textContent = caracteres
        ? `Llevas ${caracteres} caracteres.`
        : "Empieza a escribir para crear una tarea.";
    });

    this.elements.taskList.addEventListener("click", (event) => {
      const card = event.target.closest("[data-id]");

      if (!card) {
        return;
      }

      const { id } = card.dataset;

      if (event.target.closest(".action-delete")) {
        this.eliminarTarea(id);
      }

      if (event.target.closest(".action-edit")) {
        this.prepararEdicion(id);
      }

      if (event.target.closest(".action-toggle")) {
        this.cambiarEstado(id);
      }
    });

    this.elements.taskList.addEventListener("mouseover", (event) => {
      const card = event.target.closest(".task-card");

      if (card) {
        this.actualizarEstadoSync(`Viendo tarea ${card.dataset.title}`);
      }
    });

    this.elements.taskList.addEventListener("mouseleave", () => {
      this.actualizarEstadoSync("Listo para trabajar");
    });
  }

  async handleSubmit(event) {
    event.preventDefault();

    const descripcion = this.elements.description.value.trim();
    const fechaLimite = this.elements.dueDate.value;

    if (!descripcion) {
      this.mostrarNotificacion("La descripción no puede estar vacía.");
      return;
    }

    this.elements.submitBtn.disabled = true;
    this.actualizarEstadoSync("Procesando tarea...");

    await this.simularRetardo();

    if (this.editingId) {
      this.gestor.actualizarTarea(this.editingId, { descripcion, fechaLimite });
      this.mostrarNotificacion("Tarea actualizada correctamente.");
    } else {
      const tarea = new Tarea({ descripcion, fechaLimite });
      this.gestor.agregarTarea(tarea);
      this.mostrarNotificacion("Tarea agregada con retardo simulado.");
      this.notificarConRetraso(`Recordatorio: "${descripcion}" fue agregada hace 2 segundos.`);
    }

    this.persistir();
    this.render();
    this.resetForm();
    this.elements.submitBtn.disabled = false;
    this.actualizarEstadoSync("Listo para trabajar");
  }

  simularRetardo() {
    return new Promise((resolve) => {
      setTimeout(resolve, 700);
    });
  }

  notificarConRetraso(mensaje) {
    setTimeout(() => {
      this.mostrarNotificacion(mensaje);
    }, 2000);
  }

  cambiarEstado(id) {
    this.gestor.alternarEstado(id);
    this.persistir();
    this.render();
    this.mostrarNotificacion("Estado de la tarea actualizado.");
  }

  eliminarTarea(id) {
    this.gestor.eliminarTarea(id);
    this.persistir();
    this.render();
    this.mostrarNotificacion("Tarea eliminada.");
  }

  prepararEdicion(id) {
    const tarea = this.gestor.obtenerTarea(id);

    if (!tarea) {
      return;
    }

    this.editingId = id;
    this.elements.taskId.value = tarea.id;
    this.elements.description.value = tarea.descripcion;
    this.elements.dueDate.value = tarea.fechaLimite;
    this.elements.submitBtn.textContent = "Guardar cambios";
    this.elements.liveHint.textContent = "Modo edición activado.";
    this.elements.description.focus();
    this.actualizarEstadoSync(`Editando tarea ${tarea.descripcion}`);
  }

  handleClearAll() {
    this.gestor.limpiar();
    this.persistir();
    this.render();
    this.resetForm();
    this.mostrarNotificacion("Se eliminaron todas las tareas.");
  }

  iniciarReloj() {
    const renderClock = () => {
      const ahora = new Date();
      this.elements.clock.textContent = ahora.toLocaleTimeString("es-CL");
    };

    renderClock();
    setInterval(renderClock, 1000);
  }

  iniciarCountdown() {
    const actualizarCountdown = () => this.actualizarSoloCountdowns();
    actualizarCountdown();
    this.countdownInterval = setInterval(actualizarCountdown, 1000);
  }

  actualizarSoloCountdowns() {
    document.querySelectorAll("[data-countdown]").forEach((node) => {
      const dueDate = node.dataset.countdown;
      node.textContent = this.formatearTiempoRestante(dueDate);
    });
  }

  formatearTiempoRestante(fechaLimite) {
    if (!fechaLimite) {
      return "Sin fecha límite definida.";
    }

    const diferencia = new Date(fechaLimite).getTime() - Date.now();

    if (Number.isNaN(diferencia)) {
      return "Fecha límite no válida.";
    }

    if (diferencia <= 0) {
      return "Fecha límite vencida.";
    }

    const segundos = Math.floor(diferencia / 1000) % 60;
    const minutos = Math.floor(diferencia / 1000 / 60) % 60;
    const horas = Math.floor(diferencia / 1000 / 60 / 60) % 24;
    const dias = Math.floor(diferencia / 1000 / 60 / 60 / 24);

    return `Tiempo restante: ${dias}d ${horas}h ${minutos}m ${segundos}s`;
  }

  mostrarNotificacion(mensaje) {
    this.elements.notification.textContent = mensaje;
  }

  actualizarEstadoSync(mensaje) {
    this.elements.syncStatus.textContent = mensaje;
  }

  persistir() {
    guardarTareas(this.gestor.tareas);
  }

  cargarDesdeLocalStorage() {
    const data = cargarTareas();

    if (!data) {
      return;
    }

    try {
      const tareas = JSON.parse(data).map((tarea) => new Tarea({
        ...tarea,
        descripcion: tarea.descripcion,
      }));
      this.gestor.reemplazarTareas(tareas);
    } catch (error) {
      this.mostrarNotificacion("No se pudieron recuperar las tareas guardadas.");
    }
  }

  obtenerTareasFiltradas() {
    const termino = this.elements.search.value.trim().toLowerCase();

    if (!termino) {
      return this.gestor.tareas;
    }

    return this.gestor.tareas.filter((tarea) =>
      tarea.descripcion.toLowerCase().includes(termino),
    );
  }

  actualizarEstadisticas() {
    const total = this.gestor.tareas.length;
    const completadas = this.gestor.tareas.filter((tarea) => tarea.estado === "completada").length;
    const pendientes = total - completadas;

    this.elements.statTotal.textContent = total;
    this.elements.statPending.textContent = pendientes;
    this.elements.statCompleted.textContent = completadas;
  }

  render() {
    const tareas = this.obtenerTareasFiltradas();
    this.elements.taskList.innerHTML = "";

    if (!tareas.length) {
      this.elements.taskList.innerHTML = `
        <li class="empty-state">
          <strong>No hay tareas para mostrar.</strong>
          <p>Agrega una nueva tarea para comenzar.</p>
        </li>
      `;
      this.actualizarEstadisticas();
      return;
    }

    const fragment = document.createDocumentFragment();

    tareas.forEach((tarea) => {
      const clone = this.elements.template.content.cloneNode(true);
      const card = clone.querySelector(".task-card");
      const title = clone.querySelector(".task-title");
      const meta = clone.querySelector(".task-meta");
      const countdown = clone.querySelector(".task-countdown");
      const status = clone.querySelector(".task-status");

      card.dataset.id = tarea.id;
      card.dataset.title = tarea.descripcion;
      card.classList.toggle("is-completed", tarea.estado === "completada");

      title.textContent = tarea.descripcion;
      meta.textContent = `Creada: ${new Date(tarea.fechaCreacion).toLocaleString("es-CL")}`;
      countdown.dataset.countdown = tarea.fechaLimite;
      countdown.textContent = this.formatearTiempoRestante(tarea.fechaLimite);
      status.textContent = tarea.estado;
      status.className = tarea.estado === "completada"
        ? "task-status badge text-bg-success"
        : "task-status badge text-bg-warning";

      fragment.appendChild(clone);
    });

    this.elements.taskList.appendChild(fragment);
    this.actualizarEstadisticas();
  }

  resetForm() {
    this.elements.form.reset();
    this.editingId = null;
    this.elements.taskId.value = "";
    this.elements.submitBtn.textContent = "Guardar tarea";
    this.elements.liveHint.textContent = "Empieza a escribir para crear una tarea.";
    this.actualizarEstadoSync("Listo para trabajar");
  }
}
