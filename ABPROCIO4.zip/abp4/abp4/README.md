# TaskFlow

Este proyecto es una aplicación sencilla para gestionar tareas. La idea fue crear una página donde se puedan agregar, editar, marcar como completadas y eliminar tareas de una forma clara, fácil de usar y optimizada con ia.

La aplicación guarda la información en el navegador, por lo que las tareas siguen ahí aunque se cierre la página y se vuelva a abrir después. También incluye detalles simples que ayudan a que se sienta más dinámica, como un pequeño retardo al guardar, mensajes informativos y una cuenta regresiva cuando una tarea tiene fecha límite.

## ¿Qué se puede hacer?

- Crear nuevas tareas.
- Editar tareas ya existentes.
- Cambiar el estado de una tarea.
- Eliminar una tarea individual.
- Eliminar todas las tareas.
- Buscar tareas por su descripción.
- Guardar automáticamente la información en `localStorage`.

## ¿Cómo está pensado el proyecto?

La aplicación está organizada de una manera simple para que sea más fácil de entender. Se separó la lógica principal, las clases de las tareas y la parte del guardado local. La intención no fue hacer algo demasiado avanzado, sino algo ordenado, funcional y coherente con lo aprendido en clases.

En la parte visual se usó Bootstrap 5 para aprovechar componentes ya listos y evitar escribir demasiado CSS. Encima de eso solo se agregaron unos pocos estilos propios para pequeños ajustes.

## ¿Cómo abrirlo?

Solo hace falta abrir el archivo `index.html` en el navegador. Desde ahí ya se puede usar la aplicación.

## Idea general de la entrega

Este trabajo busca cumplir con lo pedido en el ABP de una forma simple: una aplicación funcional, clara y fácil de explicar. No intenta verse como un producto profesional, sino como una entrega realista de alguien que está practicando JavaScript y aprendiendo a organizar mejor su código.
