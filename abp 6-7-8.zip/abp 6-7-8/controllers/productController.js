const { Product, User, sequelize } = require('../models');
const { Op } = require('sequelize');

exports.getProducts = async (req, res) => {
  try {
    const { nombre, category } = req.query;
    const where = {};

    if (nombre) {
      where.name = { [Op.like]: `%${nombre}%` };
    }
    if (category) {
      where.category = category;
    }

    const products = await Product.findAll({
      where,
      include: [{ model: User, as: 'user', attributes: ['id', 'name', 'email'] }],
      order: [['id', 'DESC']]
    });

    return res.json({
      status: 'success',
      message: 'Productos encontrados',
      data: products
    });
  } catch (error) {
    return res.status(500).json({
      status: 'error',
      message: 'Error al obtener productos: ' + error.message,
      data: null
    });
  }
};

exports.getProductById = async (req, res) => {
  try {
    const { id } = req.params;
    const product = await Product.findByPk(id, {
      include: [{ model: User, as: 'user', attributes: ['id', 'name', 'email'] }]
    });

    if (!product) {
      return res.status(404).json({
        status: 'error',
        message: 'Producto no encontrado',
        data: null
      });
    }

    return res.json({
      status: 'success',
      message: 'Producto encontrado',
      data: product
    });
  } catch (error) {
    return res.status(500).json({
      status: 'error',
      message: 'Error al obtener producto: ' + error.message,
      data: null
    });
  }
};

exports.createProduct = async (req, res) => {
  try {
    const { name, category, price, description, image } = req.body;
    const userId = req.user ? req.user.id : 1;

    if (!name || !category || !price) {
      return res.status(400).json({
        status: 'error',
        message: 'Nombre, categoría y precio son obligatorios',
        data: null
      });
    }

    const product = await Product.create({
      name,
      category,
      price: parseFloat(price),
      description,
      image: image || '/uploads/default-product.png',
      userId
    });

    return res.status(201).json({
      status: 'success',
      message: 'Producto creado exitosamente',
      data: product
    });
  } catch (error) {
    return res.status(500).json({
      status: 'error',
      message: 'Error al crear producto: ' + error.message,
      data: null
    });
  }
};

exports.updateProduct = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, category, price, description, image } = req.body;

    const product = await Product.findByPk(id);
    if (!product) {
      return res.status(404).json({
        status: 'error',
        message: 'Producto no encontrado',
        data: null
      });
    }

    if (name) product.name = name;
    if (category) product.category = category;
    if (price !== undefined) product.price = parseFloat(price);
    if (description !== undefined) product.description = description;
    if (image) product.image = image;

    await product.save();

    return res.json({
      status: 'success',
      message: 'Producto actualizado',
      data: product
    });
  } catch (error) {
    return res.status(500).json({
      status: 'error',
      message: 'Error al actualizar producto: ' + error.message,
      data: null
    });
  }
};

exports.deleteProduct = async (req, res) => {
  try {
    const { id } = req.params;
    const product = await Product.findByPk(id);

    if (!product) {
      return res.status(404).json({
        status: 'error',
        message: 'Producto no encontrado',
        data: null
      });
    }

    await product.destroy();

    return res.json({
      status: 'success',
      message: 'Producto eliminado',
      data: null
    });
  } catch (error) {
    return res.status(500).json({
      status: 'error',
      message: 'Error al eliminar producto: ' + error.message,
      data: null
    });
  }
};

exports.testTransaction = async (req, res) => {
  const { simulateError } = req.body;
  const t = await sequelize.transaction();

  try {
    const product = await Product.create({
      name: 'Producto Test Transacción',
      category: 'Pruebas',
      price: 100,
      description: 'Prueba de transacción',
      userId: req.user ? req.user.id : 1
    }, { transaction: t });

    if (simulateError) {
      throw new Error('Error simulado para probar el rollback.');
    }

    await t.commit();

    return res.json({
      status: 'success',
      message: 'Transacción guardada correctamente',
      data: product
    });
  } catch (error) {
    await t.rollback();
    return res.status(400).json({
      status: 'error',
      message: 'Error en la transacción (Rollback ejecutado): ' + error.message,
      data: null
    });
  }
};
