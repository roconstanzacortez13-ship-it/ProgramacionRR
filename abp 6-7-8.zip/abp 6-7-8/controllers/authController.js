const jwt = require('jsonwebtoken');
const { User } = require('../models');

exports.register = async (req, res) => {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({
        status: 'error',
        message: 'Todos los campos son requeridos',
        data: null
      });
    }

    const existingUser = await User.findOne({ where: { email } });
    if (existingUser) {
      return res.status(400).json({
        status: 'error',
        message: 'El email ya está registrado',
        data: null
      });
    }

    const user = await User.create({ name, email, password });

    const token = jwt.sign(
      { id: user.id, email: user.email, name: user.name },
      process.env.JWT_SECRET || 'super_secreto_clave_jwt_alkemy_2026',
      { expiresIn: '24h' }
    );

    return res.status(201).json({
      status: 'success',
      message: 'Usuario registrado correctamente',
      data: {
        token,
        user: { id: user.id, name: user.name, email: user.email }
      }
    });
  } catch (error) {
    return res.status(500).json({
      status: 'error',
      message: 'Error al registrar: ' + error.message,
      data: null
    });
  }
};

exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        status: 'error',
        message: 'Email y contraseña requeridos',
        data: null
      });
    }

    const user = await User.findOne({ where: { email } });
    if (!user) {
      return res.status(401).json({
        status: 'error',
        message: 'Usuario no encontrado',
        data: null
      });
    }

    const isMatch = await user.validPassword(password);
    if (!isMatch) {
      return res.status(401).json({
        status: 'error',
        message: 'Contraseña incorrecta',
        data: null
      });
    }

    const token = jwt.sign(
      { id: user.id, email: user.email, name: user.name },
      process.env.JWT_SECRET || 'super_secreto_clave_jwt_alkemy_2026',
      { expiresIn: '24h' }
    );

    return res.json({
      status: 'success',
      message: 'Inicio de sesión correcto',
      data: {
        token,
        user: { id: user.id, name: user.name, email: user.email }
      }
    });
  } catch (error) {
    return res.status(500).json({
      status: 'error',
      message: 'Error al iniciar sesión: ' + error.message,
      data: null
    });
  }
};
