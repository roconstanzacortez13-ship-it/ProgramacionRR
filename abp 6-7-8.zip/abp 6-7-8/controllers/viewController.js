const { Product, User } = require('../models');
const fs = require('fs');
const path = require('path');

exports.renderHome = async (req, res) => {
  try {
    const productCount = await Product.count();
    const userCount = await User.count();
    res.render('home', {
      title: 'Inicio - Monolito Node Express',
      productCount,
      userCount
    });
  } catch (error) {
    res.render('home', { title: 'Inicio', productCount: 0, userCount: 0 });
  }
};

exports.renderLogin = (req, res) => {
  res.render('login', { title: 'Iniciar Sesión' });
};

exports.renderRegister = (req, res) => {
  res.render('register', { title: 'Registro de Usuario' });
};

exports.renderProducts = async (req, res) => {
  try {
    const productsRaw = await Product.findAll({
      include: [{ model: User, as: 'user', attributes: ['name', 'email'] }],
      order: [['id', 'DESC']]
    });

    // Convertir instancias Sequelize a objetos planos para Handlebars
    const products = productsRaw.map(p => p.get({ plain: true }));

    res.render('products', {
      title: 'Gestión de Productos',
      products
    });
  } catch (error) {
    res.render('products', {
      title: 'Gestión de Productos',
      products: [],
      error: error.message
    });
  }
};

exports.renderStatus = (req, res) => {
  const logPath = path.join(__dirname, '../logs/log.txt');
  let logsContent = 'No hay registros disponibles aún.';

  if (fs.existsSync(logPath)) {
    const content = fs.readFileSync(logPath, 'utf-8');
    const lines = content.trim().split('\n');
    logsContent = lines.slice(-15).reverse().join('\n'); // Últimos 15 accesos
  }

  res.render('status', {
    title: 'Estado del Servidor y Logs',
    uptime: process.uptime().toFixed(2),
    nodeVersion: process.version,
    platform: process.platform,
    memoryUsage: Math.round(process.memoryUsage().heapUsed / 1024 / 1024) + ' MB',
    logsContent
  });
};
