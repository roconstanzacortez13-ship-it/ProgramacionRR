const express = require('express');
const router = express.Router();
const authController = require('../../controllers/authController');

// Endpoints REST de Autenticación (Módulo 8)
router.post('/register', authController.register);
router.post('/login', authController.login);

module.exports = router;
