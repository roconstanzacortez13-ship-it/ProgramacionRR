const express = require('express');
const router = express.Router();
const upload = require('../../middlewares/uploadMiddleware');
const { authenticateToken } = require('../../middlewares/authMiddleware');

/**
 * Endpoint POST /api/upload para subida de archivos (Módulo 8, Lección 3)
 * Recibe un archivo en el campo 'file' o 'image'
 */
router.post('/', authenticateToken, (req, res) => {
  upload.single('file')(req, res, (err) => {
    if (err) {
      return res.status(400).json({
        status: 'error',
        message: err.message || 'Error al subir el archivo.',
        data: null
      });
    }

    if (!req.file) {
      return res.status(400).json({
        status: 'error',
        message: 'No se envió ningún archivo.',
        data: null
      });
    }

    const fileUrl = `/uploads/${req.file.filename}`;

    return res.status(200).json({
      status: 'success',
      message: 'Archivo subido exitosamente.',
      data: {
        filename: req.file.filename,
        originalname: req.file.originalname,
        mimetype: req.file.mimetype,
        size: req.file.size,
        url: fileUrl
      }
    });
  });
});

module.exports = router;
