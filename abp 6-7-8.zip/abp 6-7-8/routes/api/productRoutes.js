const express = require('express');
const router = express.Router();
const productController = require('../../controllers/productController');
const { authenticateToken } = require('../../middlewares/authMiddleware');

// Rutas Públicas (Lectura)
router.get('/', productController.getProducts);
router.get('/:id', productController.getProductById);

// Rutas Privadas Protegidas con JWT (Escritura / Modificación) - Módulo 8
router.post('/', authenticateToken, productController.createProduct);
router.put('/:id', authenticateToken, productController.updateProduct);
router.delete('/:id', authenticateToken, productController.deleteProduct);

// Ruta para prueba de Transaccionalidad y Rollback (Módulo 7, Lección 4)
router.post('/transaction-test', authenticateToken, productController.testTransaction);

module.exports = router;
