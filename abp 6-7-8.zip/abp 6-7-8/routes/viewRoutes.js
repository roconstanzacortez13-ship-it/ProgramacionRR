const express = require('express');
const router = express.Router();
const viewController = require('../controllers/viewController');

// Rutas de Vistas Handlebars (Módulo 6 & Front Monolito)
router.get('/', viewController.renderHome);
router.get('/login', viewController.renderLogin);
router.get('/register', viewController.renderRegister);
router.get('/products', viewController.renderProducts);
router.get('/status', viewController.renderStatus);

module.exports = router;
