const jwt = require('jsonwebtoken');

// Validar token JWT
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({
      status: 'error',
      message: 'Token requerido',
      data: null
    });
  }

  jwt.verify(token, process.env.JWT_SECRET || 'super_secreto_clave_jwt_alkemy_2026', (err, user) => {
    if (err) {
      return res.status(403).json({
        status: 'error',
        message: 'Token inválido o expirado',
        data: null
      });
    }
    req.user = user;
    next();
  });
};

module.exports = {
  authenticateToken
};
