const fs = require('fs');
const path = require('path');

const logFilePath = path.join(__dirname, '../logs/log.txt');
const logsDir = path.dirname(logFilePath);

if (!fs.existsSync(logsDir)) {
  fs.mkdirSync(logsDir, { recursive: true });
}

// Middleware para registrar accesos en log.txt
const loggerMiddleware = (req, res, next) => {
  const now = new Date();
  const fecha = now.toISOString().split('T')[0];
  const hora = now.toTimeString().split(' ')[0];
  const ruta = req.originalUrl || req.url;
  const metodo = req.method;

  const logEntry = `[${fecha} ${hora}] ${metodo} - ${ruta}\n`;

  fs.appendFile(logFilePath, logEntry, (err) => {
    if (err) {
      console.error('Error al guardar log:', err.message);
    }
  });

  next();
};

module.exports = loggerMiddleware;
