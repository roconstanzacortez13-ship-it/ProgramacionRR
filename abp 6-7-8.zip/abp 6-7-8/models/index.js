const sequelize = require('../config/database');
const User = require('./User');
const Product = require('./Product');

// Relaciones
User.hasMany(Product, { foreignKey: 'userId', as: 'products', onDelete: 'CASCADE' });
Product.belongsTo(User, { foreignKey: 'userId', as: 'user' });

module.exports = {
  sequelize,
  User,
  Product
};
