-- Script de inicialización para PostgreSQL
-- Proyecto Alkemy Módulos 6, 7 y 8

-- 1. Crear base de datos (Ejecutar desde psql o pgAdmin si aún no existe)
-- CREATE DATABASE alkemy_db;

-- Usar la base de datos alkemy_db
-- \c alkemy_db;

-- 2. Tabla de Usuarios (Users)
CREATE TABLE IF NOT EXISTS "Users" (
    "id" SERIAL PRIMARY KEY,
    "name" VARCHAR(255) NOT NULL,
    "email" VARCHAR(255) NOT NULL UNIQUE,
    "password" VARCHAR(255) NOT NULL,
    "avatar" VARCHAR(255) DEFAULT '/uploads/default-avatar.png',
    "createdAt" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 3. Tabla de Productos (Products) con relación 1:N con Users
CREATE TABLE IF NOT EXISTS "Products" (
    "id" SERIAL PRIMARY KEY,
    "name" VARCHAR(255) NOT NULL,
    "category" VARCHAR(255) NOT NULL,
    "price" NUMERIC(10, 2) NOT NULL,
    "description" TEXT,
    "image" VARCHAR(255) DEFAULT '/uploads/default-product.png',
    "userId" INTEGER NOT NULL,
    "createdAt" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "fk_products_user" FOREIGN KEY ("userId") REFERENCES "Users"("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- 4. Datos iniciales de prueba (Semilla / Seed)

-- Contraseña en hash bcrypt para "123456"
INSERT INTO "Users" ("name", "email", "password", "avatar")
VALUES 
('Usuario Prueba', 'usuario@correo.com', '$2a$10$e8wF5C8Yh/yvH6zN9y9m1.lZJ.lXj6N8fJg3.h1f1.1f1.1f1.1f1', '/uploads/default-avatar.png')
ON CONFLICT ("email") DO NOTHING;

INSERT INTO "Products" ("name", "category", "price", "description", "image", "userId")
VALUES 
('Laptop Pro 15', 'Tecnología', 1299.99, 'Computadora portátil de alto rendimiento', '/uploads/default-product.png', 1),
('Teclado Mecánico RGB', 'Periféricos', 89.50, 'Teclado con switches red y retroiluminación', '/uploads/default-product.png', 1),
('Monitor 27 IPS 144Hz', 'Pantallas', 249.00, 'Monitor para diseño y gaming', '/uploads/default-product.png', 1)
ON CONFLICT DO NOTHING;
