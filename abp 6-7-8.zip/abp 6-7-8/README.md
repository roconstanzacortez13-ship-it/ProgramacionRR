# Proyecto Integrador - Módulos 6, 7 y 8

Hola! Este es mi proyecto integrador para la evaluación de los módulos 6, 7 y 8. Es una aplicación web construida con **Node.js** y **Express**, que utiliza **Handlebars** para las vistas, **PostgreSQL** como motor de base de datos y **Sequelize** como ORM.

> 🤖 **Nota de desarrollo**: Este proyecto fue desarrollado y optimizado con el apoyo de Inteligencia Artificial (AI Assistant) para estructurar el backend modular, implementar la persistencia en PostgreSQL con Sequelize, asegurar validaciones con JWT y gestionar la carga de archivos.

---

## 🛠️ Tecnologías utilizadas

- **Backend**: Node.js, Express.js
- **Plantillas**: Express-Handlebars
- **Base de Datos & ORM**: PostgreSQL con Sequelize (`pg`, `pg-hstore`)
- **Autenticación**: JSON Web Tokens (JWT) y bcryptjs
- **Carga de Archivos**: Multer
- **Persistencia simple**: Archivos de texto con el módulo `fs` de Node.js (`logs/log.txt`)

---

## 🐘 Configuración de PostgreSQL

1. Asegúrate de tener **PostgreSQL** corriendo localmente en el puerto `5432` y haber creado la base de datos `alkemy_db`.
2. Opcionalmente puedes ejecutar el script SQL de inicialización [`init.sql`](file:///C:/Users/Betan/OneDrive/Desktop/abp%206-7-8/init.sql) para crear las tablas e insertar los datos iniciales de prueba:
   ```bash
   psql -U postgres -d alkemy_db -f init.sql
   ```
3. Configura tus credenciales en el archivo `.env`:
   ```env
   DB_DIALECT=postgres
   DB_HOST=localhost
   DB_PORT=5432
   DB_NAME=alkemy_db
   DB_USER=postgres
   DB_PASS=tu_contraseña
   ```

---

## 🚀 Cómo instalar y ejecutar el proyecto

1. Abrir la terminal en la carpeta del proyecto y ejecutar:
   ```bash
   npm install
   ```
2. Iniciar en modo desarrollo:
   ```bash
   npm run dev
   ```
3. Abrir el navegador e ingresar a: `http://localhost:3000`

---

## 📁 Estructura del proyecto

- `app.js`: Archivo principal del servidor Express.
- `/config`: Conexión a la base de datos PostgreSQL mediante Sequelize.
- `/controllers`: Lógica de negocio para autenticación, productos y vistas.
- `/models`: Modelos de Sequelize (`User` y `Product`) con relación 1:N.
- `/routes`: Definición de rutas de vistas y API REST.
- `/middlewares`: Autenticación JWT, registro de logs en archivo plano y Multer.
- `/views`: Plantillas Handlebars para la interfaz web.
- `/public`: Archivos estáticos (CSS e imágenes subidas).
- `/logs`: Carpeta donde se guarda el registro `log.txt`.
- `init.sql`: Script DDL y semillas para la base de datos PostgreSQL.

---

## 📝 Justificaciones técnicas y reflexiones

- **Nombre del archivo principal**: Elegí `app.js` por ser la convención estándar en aplicaciones Express. Imprime `"Servidor iniciado"` en consola al arrancar.
- **Motor de plantillas**: Elegí Handlebars para desacoplar el servidor del front manteniendo renderización dinámica sin sobrecomplicar la estructura.
- **Base de datos y ORM**: Utilicé exclusivamente **PostgreSQL** junto a Sequelize ORM para garantizar persistencia relacional con tipos estritos, claves foráneas e integridad referencial.
- **Relación de modelos**: Relación 1:N entre `User` y `Product` (`User.hasMany(Product)`).
- **Seguridad (JWT)**: Autenticación mediante tokens JWT para proteger endpoints de modificación y creación.
- **Registro de accesos (Logs)**: Middleware con `fs.appendFile()` para auditar peticiones en `logs/log.txt`.

---

## 📡 Endpoints principales de la API

| Método | Ruta | Descripción |
|---|---|---|
| `POST` | `/api/auth/register` | Registro de usuario |
| `POST` | `/api/auth/login` | Inicio de sesión (devuelve JWT) |
| `GET` | `/api/products` | Obtener productos (permite filtrar por `?nombre=`) |
| `GET` | `/api/products/:id` | Obtener un producto por ID |
| `POST` | `/api/products` | Crear un producto (requiere JWT) |
| `PUT` | `/api/products/:id` | Editar un producto (requiere JWT) |
| `DELETE` | `/api/products/:id` | Eliminar un producto (requiere JWT) |
| `POST` | `/api/upload` | Subir archivo/imagen con Multer (requiere JWT) |
| `POST` | `/api/products/transaction-test` | Prueba de transacción con Sequelize |
