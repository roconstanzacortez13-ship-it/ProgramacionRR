const express = require('express');
const { engine } = require('express-handlebars');
const path = require('path');
require('dotenv').config();

const { sequelize } = require('./models');
const loggerMiddleware = require('./middlewares/loggerMiddleware');

const app = express();
const PORT = process.env.PORT || 3000;

// Configuración de Handlebars
app.engine('handlebars', engine({
  defaultLayout: 'main',
  layoutsDir: path.join(__dirname, 'views/layouts')
}));
app.set('view engine', 'handlebars');
app.set('views', path.join(__dirname, 'views'));

// Middlewares
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(path.join(__dirname, 'public/uploads')));
app.use(loggerMiddleware);

// Rutas
const viewRoutes = require('./routes/viewRoutes');
const authRoutes = require('./routes/api/authRoutes');
const productRoutes = require('./routes/api/productRoutes');
const uploadRoutes = require('./routes/api/uploadRoutes');

app.use('/', viewRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes);
app.use('/api/upload', uploadRoutes);

// Manejo de 404
app.use((req, res) => {
  if (req.accepts('html')) {
    return res.status(404).render('home', { title: '404 - No Encontrado' });
  }
  res.status(404).json({
    status: 'error',
    message: 'Ruta no encontrada',
    data: null
  });
});

// Iniciar servidor
const startServer = async () => {
  try {
    await sequelize.sync({ force: false });
    console.log('Base de datos PostgreSQL conectada.');

    const server = app.listen(PORT, () => {
      console.log(`Servidor iniciado en http://localhost:${PORT}`);
    });

    server.on('error', (error) => {
      if (error.code === 'EADDRINUSE') {
        const altPort = Number(PORT) + 1;
        console.warn(`El puerto ${PORT} está ocupado. Usando http://localhost:${altPort}`);
        app.listen(altPort);
      }
    });
  } catch (error) {
    console.error('Error al iniciar servidor:', error.message);
  }
};

startServer();

module.exports = app;
