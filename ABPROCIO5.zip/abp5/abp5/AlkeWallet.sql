
CREATE DATABASE alkewallet;


-- ------------------------------------------------------------
-- 2. CREACION DE TABLAS
-- ------------------------------------------------------------

CREATE TABLE moneda (
    currency_id     SERIAL PRIMARY KEY,
    currency_name   VARCHAR(50) NOT NULL,
    currency_symbol VARCHAR(5)  NOT NULL
);

CREATE TABLE usuario (
    user_id             SERIAL PRIMARY KEY,
    nombre              VARCHAR(100) NOT NULL,
    correo_electronico  VARCHAR(150) NOT NULL UNIQUE,
    contrasena          VARCHAR(255) NOT NULL,
    saldo               DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    currency_id         INT NOT NULL,
    CONSTRAINT fk_usuario_moneda
        FOREIGN KEY (currency_id) REFERENCES moneda(currency_id)
);


CREATE TABLE transaccion (
    transaction_id     SERIAL PRIMARY KEY,
    sender_user_id      INT NOT NULL,
    receiver_user_id    INT NOT NULL,
    importe             DECIMAL(12,2) NOT NULL,
    transaction_date    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_transaccion_sender
        FOREIGN KEY (sender_user_id) REFERENCES usuario(user_id),
    CONSTRAINT fk_transaccion_receiver
        FOREIGN KEY (receiver_user_id) REFERENCES usuario(user_id)
);

-- ------------------------------------------------------------
-- 3. DATOS DE PRUEBA
-- ------------------------------------------------------------

INSERT INTO moneda (currency_name, currency_symbol) VALUES
    ('Peso Argentino', '$'),
    ('Dolar Estadounidense', 'US$'),
    ('Euro', '€');

INSERT INTO usuario (nombre, correo_electronico, contrasena, saldo, currency_id) VALUES
    ('Ana Perez',    'ana.perez@mail.com',    'clave123', 1500.00, 1),
    ('Luis Gomez',   'luis.gomez@mail.com',   'clave456', 800.50,  2),
    ('Marta Diaz',   'marta.diaz@mail.com',   'clave789', 300.00,  3);

INSERT INTO transaccion (sender_user_id, receiver_user_id, importe, transaction_date) VALUES
    (1, 2, 100.00, '2026-01-10 10:15:00'),
    (2, 3, 50.25,  '2026-02-05 14:30:00'),
    (1, 3, 200.00, '2026-03-01 09:00:00');

-- ------------------------------------------------------------
-- 4. CONSULTAS SQL SOLICITADAS
-- ------------------------------------------------------------

SELECT m.currency_name
FROM moneda m
INNER JOIN usuario u ON u.currency_id = m.currency_id
WHERE u.user_id = 1;


SELECT * FROM transaccion;


SELECT *
FROM transaccion
WHERE sender_user_id = 1 OR receiver_user_id = 1;


UPDATE usuario
SET correo_electronico = 'ana.nueva@mail.com'
WHERE user_id = 1;


DELETE FROM transaccion
WHERE transaction_id = 3;
