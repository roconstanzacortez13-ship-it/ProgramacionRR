const resultado = document.getElementById("resultado");
const historial = [];

// Esta funcion muestra un mensaje corto dentro de la pagina.
function mostrarMensajePantalla(texto) {
  console.log("Aqui funciona la parte de mostrar mensaje en pantalla.");
  resultado.innerHTML = `<p>${texto}</p>`;
}

// Esta funcion abre el menu principal para que la persona elija una opcion.
function mostrarMenu() {
  console.log("Se muestra el menu principal.");
  return prompt(
    "Calculadora IMC\n\n" +
    "Selecciona una opcion:\n" +
    "1. Calcular IMC\n" +
    "2. Ver historial\n" +
    "3. Ver resumen\n" +
    "4. Salir"
  );
}

// Esta funcion pide un numero y lo valida para evitar errores.
function solicitarNumero(mensaje) {
  let valor = null;

  while (valor === null) {
    const entrada = prompt(mensaje);

    if (entrada === null) {
      return null;
    }

    const numero = Number(entrada);

    if (!Number.isNaN(numero) && numero > 0) {
      console.log("Se registra un numero valido:", numero);
      valor = numero;
    } else {
      alert("Ingresa un numero valido mayor que cero.");
      console.log("Entrada invalida detectada:", entrada);
    }
  }

  return valor;
}

// Esta funcion revisa el IMC y devuelve la categoria correspondiente.
function obtenerCategoria(imc) {
  console.log("Estoy revisando la categoria del IMC.");

  if (imc < 18.5) {
    return "Bajo peso";
  }

  if (imc < 25) {
    return "Peso normal";
  }

  if (imc < 30) {
    return "Sobrepeso";
  }

  return "Obesidad";
}

// Esta funcion hace la operacion matematica del IMC usando peso y altura.
function calcularImc(peso, altura) {
  console.log("Aqui se calcula el IMC con peso y altura.");
  return peso / (altura * altura);
}

// Esta funcion crea un objeto con todos los datos del calculo.
function crearRegistro(nombre, peso, altura, imc, categoria) {
  console.log("Se arma el objeto del nuevo registro.");
  return {
    nombre: nombre,
    peso: peso,
    altura: altura,
    imc: Number(imc.toFixed(2)),
    categoria: categoria
  };
}

// Hice esta funcion para practicar, pero al final no era necesaria para el resultado principal.
function convertirAlturaACentimetros(altura) {
  console.log("Prueba de conversion de altura:", altura);
  return altura * 100;
}

// Pense en usar esta funcion para recomendaciones, pero por ahora solo queda como practica.
function darConsejoSegunImc(imc) {
  console.log("Probando una funcion extra de consejos.");

  if (imc < 18.5) {
    return "Seria bueno revisar una alimentacion que ayude a subir de peso.";
  }

  if (imc < 25) {
    return "Vas dentro de un rango considerado normal.";
  }

  if (imc < 30) {
    return "Podria servir acompañar esto con mas actividad fisica.";
  }

  return "Seria bueno consultar orientacion profesional para un mejor control.";
}

// Esta funcion pide los datos, calcula el IMC y guarda el resultado en el historial.
function registrarCalculo() {
  console.log("Empieza el registro de un nuevo calculo.");
  const nombre = prompt("Ingresa el nombre de la persona:") || "Persona sin nombre";
  const peso = solicitarNumero("Ingresa el peso en kilogramos:");
  const altura = solicitarNumero("Ingresa la altura en metros:");

  if (peso === null || altura === null) {
    alert("Operacion cancelada.");
    console.log("El usuario cancelo el ingreso de datos.");
    return;
  }

  const imc = calcularImc(peso, altura);
  const categoria = obtenerCategoria(imc);
  const registro = crearRegistro(nombre, peso, altura, imc, categoria);
  const alturaEnCentimetros = convertirAlturaACentimetros(altura);
  const consejo = darConsejoSegunImc(imc);

  historial.push(registro);

  console.log("Nuevo registro guardado:", registro);
  console.log("Historial completo:", historial);
  console.log("Dato extra de practica, altura en cm:", alturaEnCentimetros);
  console.log("Consejo generado de prueba:", consejo);

  mostrarMensajePantalla(
    `Ultimo resultado: ${registro.nombre} tiene un IMC de ${registro.imc} (${registro.categoria}).`
  );

  alert(
    `${registro.nombre}\n` +
    `IMC: ${registro.imc}\n` +
    `Clasificacion: ${registro.categoria}`
  );
}

// Esta funcion recorre el historial y muestra cada registro en consola.
function mostrarHistorial() {
  console.log("Entrando a la opcion de historial.");

  if (historial.length === 0) {
    console.log("No hay registros en el historial.");
    alert("Todavia no existen calculos guardados.");
    return;
  }

  console.log("Mostrando historial de calculos:");

  for (let index = 0; index < historial.length; index += 1) {
    const registro = historial[index];
    console.log(
      `${index + 1}. ${registro.nombre} | Peso: ${registro.peso} kg | Altura: ${registro.altura} m | IMC: ${registro.imc} | ${registro.categoria}`
    );
  }

  alert("Revisa la consola para ver el historial completo.");
}

// Esta funcion suma todos los IMC guardados y obtiene el promedio.
function calcularPromedioImc() {
  console.log("Calculando promedio del historial.");

  if (historial.length === 0) {
    return 0;
  }

  let suma = 0;

  for (let index = 0; index < historial.length; index += 1) {
    console.log("Sumando IMC del registro:", historial[index].imc);
    suma += historial[index].imc;
  }

  return suma / historial.length;
}

// Esta funcion muestra un pequeno resumen con la cantidad de registros y el promedio.
function mostrarResumen() {
  console.log("Entrando a la opcion de resumen.");

  if (historial.length === 0) {
    console.log("No es posible generar resumen sin registros.");
    alert("Aun no hay datos para resumir.");
    return;
  }

  const promedio = calcularPromedioImc();
  const ultimoRegistro = historial[historial.length - 1];

  console.log("Resumen del historial:");
  console.log("Cantidad de registros:", historial.length);
  console.log("Promedio de IMC:", promedio.toFixed(2));
  console.log("Ultimo registro:", ultimoRegistro);

  alert(
    `Cantidad de registros: ${historial.length}\n` +
    `Promedio IMC: ${promedio.toFixed(2)}\n` +
    `Ultimo registro: ${ultimoRegistro.nombre}`
  );
}

// Esta funcion inicia toda la aplicacion y mantiene activo el menu hasta salir.
function iniciarAplicacion() {
  console.clear();
  console.log("Aplicacion de consola iniciada.");
  console.log("Abre la consola para revisar los registros y resultados.");
  mostrarMensajePantalla("La aplicacion esta activa en la consola del navegador.");

  let continuar = true;

  while (continuar) {
    const opcion = mostrarMenu();
    console.log("El usuario eligio esta opcion:", opcion);

    if (opcion === null || opcion === "4") {
      continuar = false;
      console.log("La aplicacion finalizo correctamente.");
      alert("Gracias por usar la calculadora IMC.");
    } else if (opcion === "1") {
      registrarCalculo();
    } else if (opcion === "2") {
      mostrarHistorial();
    } else if (opcion === "3") {
      mostrarResumen();
    } else {
      alert("Selecciona una opcion valida del menu.");
      console.log("Opcion invalida:", opcion);
    }
  }
}

iniciarAplicacion();
