# Calculadora IMC en consola

Este proyecto corresponde a una aplicacion JavaScript orientada a ejecutarse desde la consola del navegador.

## Funcionamiento

Al abrir `index.html`, el archivo `assets/js/app.js` inicia un menu interactivo usando `prompt`, `alert` y `console.log`.

Las opciones disponibles son:

- Calcular IMC de una persona
- Ver historial de calculos
- Ver resumen del historial
- Salir

## Conceptos aplicados

- Variables y constantes
- Condicionales
- Ciclo `while`
- Funciones reutilizables
- Arreglos para guardar el historial
- Objetos para almacenar cada registro de IMC
- Validacion de entradas

## Como probarlo

1. Abrir `index.html` en el navegador.
2. Abrir la consola del navegador.
3. Seguir las instrucciones de los cuadros `prompt`.
4. Revisar los resultados y registros en `console.log`.

## Nota

Este readme fue creado con chatgpt para acelerar la explicacion y documentacion